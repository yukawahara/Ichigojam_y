=== UPDATE LPC1100v1.1.LBR ===

Fixes:
1. WLCSP package cream
Description: The cream for the WLCSP package was disabled in V1, this is fixed in V1.1

2. LQFP48 package silkscreen
Description: A part of the LQFP48 package outline placed in tPlace layer overlaps the tStop layer which gave Stop Mask 
DRC errors. This is fixed in v1.1.

