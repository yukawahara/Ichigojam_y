==========================================
AKIZUKI-Eagle-Library
==========================================

■注意書き
-----------------------------------------

秋月電子通商様で販売している部品をライブラリ化するプロジェクトです。

秋月電子通商様とは一切関わりが無い個人のプロジェクトです。

たまにミスが有りますので、最終チェックは御自身で判断してください。

ミスに気が付きましたらご連絡ください。

    kitagami@artifactnoise.com まで

また、作って欲しいライブラリがあれば以下のフォームへ

    https://docs.google.com/forms/d/e/1FAIpQLSdrMkiEMbF2kPQSdAUvBFTaOkSK_Yb0Dbv86sXLRHxQ9BmUOQ/viewform?usp=sf_link

ライセンスはMITライセンスです。
(ライブラリを再配布する時だけ名前を残していただければ幸せです。)

    The MIT License (MIT)
    Copyright (c) 2013 nonNoise(Y.Kitagami)



■更新履歴 
-----------------------------------------

- 2018/02/05　大型アップデート　仕切り直し

- 2018/03/02　M-02038_HRD05003 アンケート回答分追加


■ライブラリ リスト 
-----------------------------------------

::

    P-08669_HUSG-12.000-20
    P-08278_SO1602AWYB-UC-WB-U
    P-07005_AQM1248A
    P-06925_BC-2001
    P-06185_SKRPACE010
    P-05663_CSX-750PB
    P-05285_ATM0430D5
    P-05080_RK0971221-F15-C0-A103
    P-04944_LS027B4DH01
    P-04809_RJLD260TC1
    P-04538_SG8002DC
    P-04118_PKM13EPYH4000
    P-04005_VT-200-F32.768KHZ
    P-03647_SW
    P-03277_VR_3362P
    P-02285_CSTCE20M0V51-R0
    P-01767-16MHZ
    P-01675_SD1602VBWB
    P-01306_TB111-2-2-U-1-1
    P-00819_J0011D21B
    P-00706_CH25-2032LF
    P-00038_SC1602B
    M-11007_AE-TTL-232R-CN
    M-09607_ESP-WROOM-02
    M-08569_EDISON
    M-06353_R-78E5.0-0.5
    M-06195_XBEE
    M-06174_LCMXO2-7000HE-B-EVN
    M-05825_AE-FXMA2102
    M-04522_FXMA108
    M-04135_MAU109
    M-02990_AE-FT2232
    M-02038_HRD05003
    K-08846_EDISON-BASE64
    K-01977_FT232KIT
    I-12644_OSL10326-IR
    I-11003_MACHXO2-256_LCMXO2-256HC-4TG100C
    I-10673_NJM2884U1-33
    I-07639_PIC15F1501
    I-07330_TPL222AF
    I-06950_DS1307ZN
    I-06734_2SA1015
    I-06491_PL-IRM2161
    I-06477_2SC1815
    I-05967_MMBT3906
    I-05738_OSL641501-BRA
    I-05568_S108T02
    I-05448_NJM2866F33
    I-04557_PIC12F1822
    I-04525_R8C-M12A
    I-04524_R8C-M11A
    I-04290_OSX10201
    I-04269_P-FET_BSS84
    I-03944_OSL40562-IG
    I-03479_FT2232D
    I-02791_LT1785CN8
    I-02331_LME49600
    I-02247_NJM2845
    I-02165_CY7C1041DV33
    I-02131_R8C_29
    I-02129_R8C_2AB
    I-01444_OSTA71A1D-A
    I-00789_C-2AA0SRDT
    I-00040_LT-5003D
    C-09598_PLT133/T10W
    C-09597_PLR135/T10
    C-08958_MJ-352W-0
    C-07675_USB-B
    C-07674_USB-A
    C-05843_USB-MINI-B
    C-05254_ZX62D-B-5PA8
    C-02236_WM17117-ND
    C-01604_2.1MMJACK
    C-00159_RJ45_AKITUKI
